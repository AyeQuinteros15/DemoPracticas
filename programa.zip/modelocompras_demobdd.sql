-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema modulocompras_demo
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema modulocompras_demo
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `modulocompras_demo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `modulocompras_demo` ;

-- -----------------------------------------------------
-- Table `modulocompras_demo`.`perfiles`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`perfiles` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom_perfil` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `nom_perfil` (`nom_perfil` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`sucursales`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`sucursales` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom_suc` VARCHAR(100) NOT NULL,
  `direccion_suc` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `nom_suc` (`nom_suc` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`usuarios`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`usuarios` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom_usuario` VARCHAR(50) NOT NULL,
  `apellido_usuario` VARCHAR(50) NOT NULL,
  `usuario` VARCHAR(50) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `perfil_id` INT NOT NULL,
  `sucursal_id` INT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `usuario` (`usuario` ASC) VISIBLE,
  INDEX `perfil_id` (`perfil_id` ASC) VISIBLE,
  INDEX `sucursal_id` (`sucursal_id` ASC) VISIBLE,
  CONSTRAINT `usuarios_ibfk_1`
    FOREIGN KEY (`perfil_id`)
    REFERENCES `modulocompras_demo`.`perfiles` (`id`),
  CONSTRAINT `usuarios_ibfk_2`
    FOREIGN KEY (`sucursal_id`)
    REFERENCES `modulocompras_demo`.`sucursales` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`sectores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`sectores` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `nombre` (`nombre` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`notas_pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`notas_pedido` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `numero` VARCHAR(30) NOT NULL,
  `usuario_id` INT NOT NULL,
  `descripcion` TEXT NULL DEFAULT NULL,
  `prioridad` TINYINT(1) NULL DEFAULT '0',
  `fecha_creacion` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_entrega` DATE NULL DEFAULT NULL,
  `gerente_solicitante` VARCHAR(100) NULL DEFAULT NULL,
  `observaciones` TEXT NULL DEFAULT NULL,
  `archivo_adjunto` VARCHAR(255) NULL DEFAULT NULL,
  `sector_id` INT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `numero` (`numero` ASC) VISIBLE,
  INDEX `usuario_id` (`usuario_id` ASC) VISIBLE,
  INDEX `sector_id` (`sector_id` ASC) VISIBLE,
  CONSTRAINT `notas_pedido_ibfk_1`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `modulocompras_demo`.`usuarios` (`id`),
  CONSTRAINT `notas_pedido_ibfk_2`
    FOREIGN KEY (`sector_id`)
    REFERENCES `modulocompras_demo`.`sectores` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`proveedores`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`proveedores` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nom_proveedor` VARCHAR(50) NOT NULL,
  `apellido_proveedor` VARCHAR(50) NOT NULL,
  `dni_prov` VARCHAR(20) NULL DEFAULT NULL,
  `telefono` VARCHAR(20) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `dni_prov` (`dni_prov` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`ordenes_compra`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`ordenes_compra` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `numero` VARCHAR(30) NOT NULL,
  `nota_pedido_id` INT NOT NULL,
  `numero_cotizacion` VARCHAR(50) NULL DEFAULT NULL,
  `fecha_emision` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `observaciones` TEXT NULL DEFAULT NULL,
  `observaciones_internas` TEXT NULL DEFAULT NULL,
  `archivo_pdf` VARCHAR(255) NULL DEFAULT NULL,
  `descuento_porcentaje` DECIMAL(5,2) NULL DEFAULT NULL,
  `iva_porcentaje` DECIMAL(5,2) NULL DEFAULT NULL,
  `otro_impuesto_porcentaje` DECIMAL(5,2) NULL DEFAULT NULL,
  `proveedor_id` INT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `numero` (`numero` ASC) VISIBLE,
  INDEX `nota_pedido_id` (`nota_pedido_id` ASC) VISIBLE,
  INDEX `proveedor_id` (`proveedor_id` ASC) VISIBLE,
  CONSTRAINT `ordenes_compra_ibfk_1`
    FOREIGN KEY (`nota_pedido_id`)
    REFERENCES `modulocompras_demo`.`notas_pedido` (`id`),
  CONSTRAINT `ordenes_compra_ibfk_2`
    FOREIGN KEY (`proveedor_id`)
    REFERENCES `modulocompras_demo`.`proveedores` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`entregas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`entregas` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `orden_compra_id` INT NOT NULL,
  `producto` VARCHAR(100) NOT NULL,
  `cantidad` INT NOT NULL,
  `usuario_id` INT NOT NULL,
  `fecha` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `orden_compra_id` (`orden_compra_id` ASC) VISIBLE,
  INDEX `usuario_id` (`usuario_id` ASC) VISIBLE,
  CONSTRAINT `entregas_ibfk_1`
    FOREIGN KEY (`orden_compra_id`)
    REFERENCES `modulocompras_demo`.`ordenes_compra` (`id`),
  CONSTRAINT `entregas_ibfk_2`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `modulocompras_demo`.`usuarios` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`estados_np`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`estados_np` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `estados_np` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `estados_np` (`estados_np` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`estados_oc`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`estados_oc` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `estados_oc` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `estados_oc` (`estados_oc` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 10
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`facturas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`facturas` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `orden_compra_id` INT NOT NULL,
  `numero_factura` VARCHAR(50) NULL DEFAULT NULL,
  `numero_remito` VARCHAR(50) NULL DEFAULT NULL,
  `archivo_pdf` VARCHAR(255) NOT NULL,
  `fecha` DATE NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `orden_compra_id` (`orden_compra_id` ASC) VISIBLE,
  CONSTRAINT `facturas_ibfk_1`
    FOREIGN KEY (`orden_compra_id`)
    REFERENCES `modulocompras_demo`.`ordenes_compra` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`historial_np`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`historial_np` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nota_pedido_id` INT NOT NULL,
  `estado_id` INT NOT NULL,
  `usuario_id` INT NOT NULL,
  `fecha` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `observaciones` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `nota_pedido_id` (`nota_pedido_id` ASC) VISIBLE,
  INDEX `estado_id` (`estado_id` ASC) VISIBLE,
  INDEX `usuario_id` (`usuario_id` ASC) VISIBLE,
  CONSTRAINT `historial_np_ibfk_1`
    FOREIGN KEY (`nota_pedido_id`)
    REFERENCES `modulocompras_demo`.`notas_pedido` (`id`),
  CONSTRAINT `historial_np_ibfk_2`
    FOREIGN KEY (`estado_id`)
    REFERENCES `modulocompras_demo`.`estados_np` (`id`),
  CONSTRAINT `historial_np_ibfk_3`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `modulocompras_demo`.`usuarios` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`historial_oc`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`historial_oc` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `orden_compra_id` INT NOT NULL,
  `estado_id` INT NOT NULL,
  `usuario_id` INT NOT NULL,
  `fecha` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  `observaciones` TEXT NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `orden_compra_id` (`orden_compra_id` ASC) VISIBLE,
  INDEX `estado_id` (`estado_id` ASC) VISIBLE,
  INDEX `usuario_id` (`usuario_id` ASC) VISIBLE,
  CONSTRAINT `historial_oc_ibfk_1`
    FOREIGN KEY (`orden_compra_id`)
    REFERENCES `modulocompras_demo`.`ordenes_compra` (`id`),
  CONSTRAINT `historial_oc_ibfk_2`
    FOREIGN KEY (`estado_id`)
    REFERENCES `modulocompras_demo`.`estados_oc` (`id`),
  CONSTRAINT `historial_oc_ibfk_3`
    FOREIGN KEY (`usuario_id`)
    REFERENCES `modulocompras_demo`.`usuarios` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`items_np`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`items_np` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nota_pedido_id` INT NOT NULL,
  `descripcion` TEXT NOT NULL,
  `cantidad` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `nota_pedido_id` (`nota_pedido_id` ASC) VISIBLE,
  CONSTRAINT `items_np_ibfk_1`
    FOREIGN KEY (`nota_pedido_id`)
    REFERENCES `modulocompras_demo`.`notas_pedido` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`items_oc`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`items_oc` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `orden_compra_id` INT NOT NULL,
  `descripcion` TEXT NOT NULL,
  `cantidad` INT NOT NULL,
  `precio_unitario` DECIMAL(10,2) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `orden_compra_id` (`orden_compra_id` ASC) VISIBLE,
  CONSTRAINT `items_oc_ibfk_1`
    FOREIGN KEY (`orden_compra_id`)
    REFERENCES `modulocompras_demo`.`ordenes_compra` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `modulocompras_demo`.`stock`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `modulocompras_demo`.`stock` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `sucursal_id` INT NOT NULL,
  `producto` VARCHAR(100) NOT NULL,
  `cantidad` INT NULL DEFAULT '0',
  `minimo` INT NULL DEFAULT '0',
  `maximo` INT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  INDEX `sucursal_id` (`sucursal_id` ASC) VISIBLE,
  CONSTRAINT `stock_ibfk_1`
    FOREIGN KEY (`sucursal_id`)
    REFERENCES `modulocompras_demo`.`sucursales` (`id`))
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
