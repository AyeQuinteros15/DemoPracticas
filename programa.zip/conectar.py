import mysql.connector
from mysql.connector import Error

class ConexionMYSqL:    
    def ConectarDB():
        try:
            conexion=mysql.connector.connect(
                host="localhost",
                database="modulocompras_demo",
                user="root",
                password="exequielaidar"
            )
            print ("Conectado exitosamente")
            return conexion #Se conecta a la base de datos si los datos son correctos
        except mysql.connector.Error as error:
            print ("Error al conectar la Base de Datos: {}".format(error))
            return conexion
        