class Usuario():
    def __init__(self, usuario="", password=""):
        self._usuario=usuario
        self._password=password