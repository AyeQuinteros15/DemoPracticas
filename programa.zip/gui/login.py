from PyQt6 import QtWidgets, uic
from PyQt6.QtWidgets import QMessageBox
from data.usuario import UsuarioData
from model.user import Usuario


class Login():
    def __init__(self):
        self.login=uic.loadUi("gui/login.ui")
        self.initGUI()
        self.login.lblMensaje.setText("")
        self.login.show()

    def ingresar(self):
        if len(self.login.txtUsuarioLogin.text())<2:
              self.login.lblMensaje.setText("Ingrese un usuario válido")
              self.login.txtUsuarioLogin.setFocus()
        elif len(self.login.txtClaveLogin.text())<2:
             self.login.lblMensaje.setText("Ingrese una contraseña válida")
             self.login.txtClaveLogin.setFocus()
        else:
           Usu=Usuario(usuario=self.login.txtUsuarioLogin.text(),password=self.login.txtClaveLogin.text())
           UsuData=UsuarioData()
           res=UsuData.login(Usu)
           if res:
               self.login.lblMensaje.setText("DATOS CORRECTOS")
           else:
               self.login.lblMensaje.setText("DATOS INCORRECTOS")
               
    
    def initGUI(self):
        self.login.btnAccederLogin.clicked.connect(self.ingresar)