import conectar as con
from model.user import Usuario

class UsuarioData():
     def login(self, usuario:Usuario):
        self.db=con.ConexionMYSqL.ConectarDB()
        self.cursor=self.db.cursor()
        res=self.cursor.execute("SELECT * FROM usuarios WHERE usuario=%s AND password=%s".format(usuario._usuario,usuario._password))
        fila=res.fetchone()
        if fila:
            usuario=Usuario(usuario=fila[3],password=fila[4])
            return usuario
        else:
            return None
