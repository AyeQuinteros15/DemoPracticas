-- Perfiles de usuario
CREATE TABLE IF NOT EXISTS perfiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_perfil TEXT NOT NULL UNIQUE
);

-- Sucursales
CREATE TABLE IF NOT EXISTS sucursales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_suc TEXT NOT NULL UNIQUE,
    direccion_suc TEXT
);

-- Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_usuario TEXT NOT NULL,
    apellido_usuario TEXT NOT NULL,
    usuario TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    perfil_id INTEGER NOT NULL,
    sucursal_id INTEGER,
    FOREIGN KEY (perfil_id) REFERENCES perfiles(id),
    FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
);

-- Sectores
CREATE TABLE IF NOT EXISTS sectores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL UNIQUE
);

-- Estados de Notas de Pedido
CREATE TABLE IF NOT EXISTS estados_np (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    estados_np TEXT NOT NULL UNIQUE
);

-- Estados de Órdenes de Compra
CREATE TABLE IF NOT EXISTS estados_oc (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    estados_oc TEXT NOT NULL UNIQUE
);

-- Proveedores
CREATE TABLE IF NOT EXISTS proveedores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nom_proveedor TEXT NOT NULL,
    apellido_proveedor TEXT NOT NULL,
    dni_prov TEXT UNIQUE,
    telefono TEXT
);

-- Notas de Pedido
CREATE TABLE IF NOT EXISTS notas_pedido (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT UNIQUE NOT NULL,
    usuario_id INTEGER NOT NULL,
    sucursal_id INTEGER NOT NULL,
    sector_id INTEGER NOT NULL,
    descripcion TEXT,
    prioridad INTEGER DEFAULT 0, -- BOOLEAN en SQLite
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_entrega DATE,
    gerente_solicitante TEXT,
    observaciones TEXT,
    archivo_adjunto TEXT,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (sucursal_id) REFERENCES sucursales(id),
    FOREIGN KEY (sector_id) REFERENCES sectores(id)
);

-- Ítems de Notas de Pedido
CREATE TABLE IF NOT EXISTS items_np (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nota_pedido_id INTEGER NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INTEGER NOT NULL,
    FOREIGN KEY (nota_pedido_id) REFERENCES notas_pedido(id)
);

-- Historial de Estados de NP
CREATE TABLE IF NOT EXISTS historial_np (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nota_pedido_id INTEGER NOT NULL,
    estado_id INTEGER NOT NULL,
    usuario_id INTEGER NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observaciones TEXT,
    FOREIGN KEY (nota_pedido_id) REFERENCES notas_pedido(id),
    FOREIGN KEY (estado_id) REFERENCES estados_np(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Órdenes de Compra
CREATE TABLE IF NOT EXISTS ordenes_compra (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT UNIQUE NOT NULL,
    nota_pedido_id INTEGER NOT NULL,
    proveedor_id INTEGER,
    numero_cotizacion TEXT,
    fecha_emision TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    fecha_recepcion DATE,
    observaciones TEXT,
    observaciones_internas TEXT,
    archivo_pdf TEXT,
    descuento_porcentaje REAL,
    iva_porcentaje REAL,
    otro_impuesto_porcentaje REAL,
    fecha_vencimiento DATE,
    creado_por INTEGER,
    FOREIGN KEY (nota_pedido_id) REFERENCES notas_pedido(id),
    FOREIGN KEY (proveedor_id) REFERENCES proveedores(id),
    FOREIGN KEY (creado_por) REFERENCES usuarios(id)
);

-- Ítems de Órdenes de Compra
CREATE TABLE IF NOT EXISTS items_oc (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    orden_compra_id INTEGER NOT NULL,
    descripcion TEXT NOT NULL,
    cantidad INTEGER NOT NULL,
    precio_unitario REAL,
    FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id)
);

-- Historial de Estados de OC
CREATE TABLE IF NOT EXISTS historial_oc (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    orden_compra_id INTEGER NOT NULL,
    estado_id INTEGER NOT NULL,
    usuario_id INTEGER NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    observaciones TEXT,
    FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id),
    FOREIGN KEY (estado_id) REFERENCES estados_oc(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Entregas parciales de OC
CREATE TABLE IF NOT EXISTS entregas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    orden_compra_id INTEGER NOT NULL,
    item_oc_id INTEGER,
    producto TEXT NOT NULL,
    cantidad INTEGER NOT NULL,
    usuario_id INTEGER NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id),
    FOREIGN KEY (item_oc_id) REFERENCES items_oc(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Facturas y Remitos
CREATE TABLE IF NOT EXISTS facturas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    orden_compra_id INTEGER NOT NULL,
    numero_factura TEXT,
    numero_remito TEXT,
    archivo_pdf TEXT NOT NULL,
    fecha DATE,
    FOREIGN KEY (orden_compra_id) REFERENCES ordenes_compra(id)
);

-- Control de Stock
CREATE TABLE IF NOT EXISTS stock (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sucursal_id INTEGER NOT NULL,
    producto TEXT NOT NULL,
    cantidad INTEGER DEFAULT 0,
    minimo INTEGER DEFAULT 0,
    maximo INTEGER DEFAULT 0,
    FOREIGN KEY (sucursal_id) REFERENCES sucursales(id)
);