import conectar as con
from model.sector import Sector
from model.sucursal import Sucursal
from model.user import Usuario, Usuario_Sesion

class UsuarioData():
    def __init__(self):
        # Conectamos a la base de datos desde el inicio
        self.db = con.ConexionMYSqL.ConectarDB()
        self.cursor = self.db.cursor()

    def login(self, usuario: Usuario_Sesion):
        query = """
            SELECT id, nom_usuario, apellido_usuario, usuario, password, perfil_id 
            FROM usuarios 
            WHERE usuario=? AND password=?
        """
        self.cursor.execute(query, (usuario._usuario, usuario._password))
        fila = self.cursor.fetchone()
        if fila:
            return Usuario(
                id=fila[0],
                nom_usuario=fila[1],
                apellido_usuario=fila[2],
                usuario=fila[3],
                password=fila[4],
                perfil_id=fila[5]
            )
        else:
            return None


    def obtener_todos_los_usuarios(self):
        try:
            self.cursor.execute("SELECT id, nom_usuario, apellido_usuario, usuario FROM usuarios")
            rows = self.cursor.fetchall()
            return [Usuario(id=row[0], nom_usuario=row[1], apellido_usuario=row[2], usuario=row[3]) for row in rows]
        except Exception as e:
            print("Error al obtener usuarios:", e)
            return []

    def obtener_usuario_por_id(self, id_usuario):
        try:
            self.cursor.execute("SELECT id, nom_usuario, apellido_usuario, usuario FROM usuarios WHERE id=?", (id_usuario,))
            row = self.cursor.fetchone()
            if row:
                return Usuario(id=row[0], nom_usuario=row[1], apellido_usuario=row[2], usuario=row[3])
            return None
        except Exception as e:
            print("Error al obtener usuario por ID:", e)
            return None
        
    def obtener_sectores(self):
            self.cursor.execute("SELECT id, nombre FROM sectores")
            rows = self.cursor.fetchall()
            return [Sector(id=row[0], nombre=row[1]) for row in rows]  # Crea modelo Sector

    def obtener_sucursales(self):
            self.cursor.execute("SELECT id, nom_suc FROM sucursales")
            rows = self.cursor.fetchall()
            return [Sucursal(id=row[0], nom_suc=row[1]) for row in rows]  # Crea modelo Sucursal