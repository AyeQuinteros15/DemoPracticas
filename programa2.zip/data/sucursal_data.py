import sqlite3
from model.sucursal import Sucursal

class SucursalData:
    def __init__(self):
        self.conn = sqlite3.connect("modulocompras.db")
        self.cursor = self.conn.cursor()

    def obtener_todos(self):
        try:
            self.cursor.execute("SELECT id, nom_suc FROM sucursales ORDER BY nom_suc ASC")
            rows = self.cursor.fetchall()
            return [Sucursal(id=row[0], nom_suc=row[1]) for row in rows]
        except Exception as e:
            print("Error al obtener sucursales:", e)
            return []

    def obtener_por_id(self, id_sucursal):
        try:
            self.cursor.execute("SELECT id, nom_suc, direccion_suc FROM sucursales WHERE id=?", (id_sucursal,))
            row = self.cursor.fetchone()
            if row:
                return Sucursal(id=row[0], nom_suc=row[1], direccion_suc=row[2])
            return None
        except Exception as e:
            print("Error al obtener sucursal por ID:", e)
            return None

    def guardar(self, sucursal):
        try:
            if sucursal.id:
                self.cursor.execute("UPDATE sucursales SET nom_suc=?, direccion_suc=? WHERE id=?", 
                                    (sucursal.nom_suc, sucursal.direccion_suc, sucursal.id))
            else:
                self.cursor.execute("INSERT INTO sucursales (nom_suc, direccion_suc) VALUES (?, ?)",
                                    (sucursal.nom_suc, sucursal.direccion_suc))
                sucursal.id = self.cursor.lastrowid
            self.conn.commit()
            return True
        except Exception as e:
            print("Error al guardar sucursal:", e)
            return False