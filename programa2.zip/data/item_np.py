import sqlite3
from model.item_np import ItemNP

class ItemNPData:
    def __init__(self):
        self.conn = sqlite3.connect("modelocompras_demobdd.db")
        self.cursor = self.conn.cursor()

    def guardar_items_de_nota(self, items, nota_pedido_id):
        try:
            self.cursor.execute("DELETE FROM items_np WHERE nota_pedido_id=?", (nota_pedido_id,))
            for item in items:
                self.cursor.execute("""
                    INSERT INTO items_np (nota_pedido_id, descripcion, cantidad)
                    VALUES (?, ?, ?)
                """, (
                    nota_pedido_id,
                    item["descripcion"],
                    item["cantidad"]
                ))
            self.conn.commit()
            return True
        except Exception as e:
            print("Error al guardar ítems:", e)
            return False