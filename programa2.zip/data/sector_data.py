import sqlite3
from model.sector import Sector

class SectorData:
    def __init__(self):
        self.conn = sqlite3.connect("modulocompras.db")
        self.cursor = self.conn.cursor()

    def obtener_todos(self):
        try:
            self.cursor.execute("SELECT id, nombre FROM sectores ORDER BY nombre ASC")
            rows = self.cursor.fetchall()
            return [Sector(id=row[0], nombre=row[1]) for row in rows]
        except Exception as e:
            print("Error al obtener sectores:", e)
            return []

    def obtener_por_id(self, id_sector):
        try:
            self.cursor.execute("SELECT id, nombre FROM sectores WHERE id=?", (id_sector,))
            row = self.cursor.fetchone()
            if row:
                return Sector(id=row[0], nombre=row[1])
            return None
        except Exception as e:
            print("Error al obtener sector por ID:", e)
            return None

    def guardar(self, sector):
        try:
            if sector.id:
                self.cursor.execute("UPDATE sectores SET nombre=? WHERE id=?", 
                                    (sector.nombre, sector.id))
            else:
                self.cursor.execute("INSERT INTO sectores (nombre) VALUES (?)",
                                    (sector.nombre,))
                sector.id = self.cursor.lastrowid
            self.conn.commit()
            return True
        except Exception as e:
            print("Error al guardar sector:", e)
            return False