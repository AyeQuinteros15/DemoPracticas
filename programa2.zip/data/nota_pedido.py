import sqlite3
from model.nota_pedido import NotaPedido

class NotaPedidoData:
    def __init__(self):
        self.conn = sqlite3.connect("modelocompras_demobdd.db")
        self.cursor = self.conn.cursor()

    def guardar(self, nota_pedido):
        try:
            if nota_pedido.id:
                # Actualizar
                self.cursor.execute("""
                    UPDATE notas_pedido SET 
                        numero=?, usuario_id=?, descripcion=?, prioridad=?,
                        fecha_creacion=?, fecha_entrega=?, gerente_solicitante=?, 
                        observaciones=?, archivo_adjunto=?, sector_id=?
                    WHERE id=?
                """, (
                    nota_pedido.numero,
                    nota_pedido.usuario_id,
                    nota_pedido.descripcion,
                    nota_pedido.prioridad,
                    nota_pedido.fecha_creacion,
                    nota_pedido.fecha_entrega,
                    nota_pedido.gerente_solicitante,
                    nota_pedido.observaciones,
                    nota_pedido.archivo_adjunto,
                    nota_pedido.sector_id,
                    nota_pedido.id
                ))
            else:
                # Insertar nueva
                self.cursor.execute("""
                    INSERT INTO notas_pedido (
                        numero, usuario_id, descripcion, prioridad,
                        fecha_creacion, fecha_entrega, gerente_solicitante,
                        observaciones, archivo_adjunto, sector_id
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    nota_pedido.numero,
                    nota_pedido.usuario_id,
                    nota_pedido.descripcion,
                    nota_pedido.prioridad,
                    nota_pedido.fecha_creacion,
                    nota_pedido.fecha_entrega,
                    nota_pedido.gerente_solicitante,
                    nota_pedido.observaciones,
                    nota_pedido.archivo_adjunto,
                    nota_pedido.sector_id
                ))
                nota_pedido.id = self.cursor.lastrowid  # Asigna el ID autogenerado
            self.conn.commit()
            return True
        except Exception as e:
            print("Error al guardar nota de pedido:", e)
            return False
    def obtener_todas_las_notas_pedido(self):
        try:
            query = """
                SELECT id, numero, descripcion, prioridad, 
                    fecha_creacion, fecha_entrega, sector_id
                FROM notas_pedido
            """
            self.cursor.execute(query)
            rows = self.cursor.fetchall()
            return [NotaPedido(
                id=row[0],
                numero=row[1],
                descripcion=row[2],
                prioridad=row[3],
                fecha_creacion=row[4],
                fecha_entrega=row[5],
                sector_id=row[6]
            ) for row in rows]
        except Exception as e:
            print("Error al obtener notas de pedido:", e)
            return []
        
    def obtener_nota_pedido_por_id(self, id_nota_pedido):
        try:
            query = """
                SELECT id, numero, descripcion, prioridad, 
                    fecha_creacion, fecha_entrega, sector_id
                FROM notas_pedido 
                WHERE id = ?
            """
            self.cursor.execute(query, (id_nota_pedido,))
            row = self.cursor.fetchone()
            if row:
                return NotaPedido(
                    id=row[0],
                    numero=row[1],
                    descripcion=row[2],
                    prioridad=row[3],
                    fecha_creacion=row[4],
                    fecha_entrega=row[5],
                    sector_id=row[6]
                )
            return None
        except Exception as e:
            print("Error al obtener nota de pedido por ID:", e)
            return None