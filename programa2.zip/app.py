from modelocompras import modeloCompras


app=modeloCompras()