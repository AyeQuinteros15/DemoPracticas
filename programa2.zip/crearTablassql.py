import sqlite3

def crear_tablas():
    try:
        conn = sqlite3.connect("modelocompras_demobdd.db")
        cursor = conn.cursor()

        with open("crear_tablas_sqlite.sql", "r", encoding="utf-8") as f:
            sql_script = f.read()

        cursor.executescript(sql_script)
        conn.commit()
        print("Tablas creadas correctamente.")
    except Exception as e:
        print("Error al crear tablas:", e)
    finally:
        if conn:
            conn.close()

if __name__ == "__main__":
    crear_tablas()