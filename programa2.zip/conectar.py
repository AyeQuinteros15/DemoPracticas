import sqlite3

class ConexionMYSqL:    
    def ConectarDB():
        try:
            conexion=sqlite3.connect("modelocompras_demobdd.db")
            print ("Conectado exitosamente")
            return conexion #Se conecta a la base de datos si los datos son correctos
        except sqlite3.Error as error:
            print ("Error al conectar la Base de Datos: {}".format(error))
            return conexion

#ConexionMYSqL.ConectarDB()