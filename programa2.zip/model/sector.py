class Sector:
    def __init__(self, id=None, nombre=""):
        self.id = id
        self.nombre = nombre