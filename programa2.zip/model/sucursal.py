class Sucursal:
    def __init__(self, id=None, nom_suc="", direccion_suc=""):
        self.id = id
        self.nom_suc = nom_suc
        self.direccion_suc = direccion_suc