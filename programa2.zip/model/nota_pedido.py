class NotaPedido:
    def __init__(self, id=None, numero=None, usuario_id=None, descripcion="", prioridad=0,
                 fecha_creacion=None, fecha_entrega=None, gerente_solicitante="", 
                 observaciones="", archivo_adjunto="", sector_id=None):
        self.id = id
        self.numero = numero
        self.usuario_id = usuario_id
        self.descripcion = descripcion
        self.prioridad = prioridad
        self.fecha_creacion = fecha_creacion
        self.fecha_entrega = fecha_entrega
        self.gerente_solicitante = gerente_solicitante
        self.observaciones = observaciones
        self.archivo_adjunto = archivo_adjunto
        self.sector_id = sector_id
        
    def obtener_datos_formulario(self):
        sector_index = self.ventana.boxSectorNP.currentIndex()
        sector_id = self.ventana.boxSectorNP.itemData(sector_index)

        return NotaPedido(
            numero=self.ventana.txtNumNP.text(),
            usuario_id=self.usuario.id if self.usuario else 1,
            descripcion="",  # Puedes vincularlo si usas un campo oculto o visible
            prioridad=0,     # Puedes vincularlo a un QCheckBox o QSpinBox
            fecha_creacion=self.ventana.fechaCrearNP.date().toString("yyyy-MM-dd"),  # Añadido
            fecha_entrega=self.ventana.fechaEntregaCrearNP.date().toString("yyyy-MM-dd"),
            gerente_solicitante=self.ventana.txtGerenteSolicitante.text(),
            observaciones=self.ventana.txtObservacionesCrearNP.toPlainText(),
            archivo_adjunto=self.ventana.txtAdjArchivo.text(),
            sector_id=sector_id
        )