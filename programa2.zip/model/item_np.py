class ItemNP:
    def __init__(self, id=None, nota_pedido_id=None, descripcion="", cantidad=0):
        self.id = id
        self.nota_pedido_id = nota_pedido_id
        self.descripcion = descripcion
        self.cantidad = cantidad