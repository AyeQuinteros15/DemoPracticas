class Usuario_Sesion():
    def __init__(self, usuario="", password=""):
        self._usuario=usuario
        self._password=password

class Usuario():
    def __init__(self, id=None, nom_usuario="", apellido_usuario="", usuario="", password="", perfil_id=0, sucursal_id=None):
        self.id = id
        self.nom_usuario = nom_usuario
        self.apellido_usuario = apellido_usuario
        self.usuario = usuario
        self.password = password
        self.perfil_id = perfil_id
        self.sucursal_id = sucursal_id