# gui/agregar_item.py

from PyQt6.QtWidgets import QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, QHBoxLayout, QMessageBox


class AgregarItemDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Agregar Ítem")
        self.layout = QVBoxLayout(self)

        # Campos del diálogo
        self.item_input = QLineEdit()
        self.descripcion_input = QLineEdit()
        self.cantidad_input = QLineEdit()

        # Etiquetas y campos
        self.layout.addWidget(QLabel("Nombre del ítem:"))
        self.layout.addWidget(self.item_input)
        self.layout.addWidget(QLabel("Descripción:"))
        self.layout.addWidget(self.descripcion_input)
        self.layout.addWidget(QLabel("Cantidad:"))
        self.layout.addWidget(self.cantidad_input)

        # Botones
        btn_layout = QHBoxLayout()
        self.btn_aceptar = QPushButton("Aceptar")
        self.btn_cancelar = QPushButton("Cancelar")
        self.btn_aceptar.clicked.connect(self.accept)
        self.btn_cancelar.clicked.connect(self.reject)
        btn_layout.addWidget(self.btn_aceptar)
        btn_layout.addWidget(self.btn_cancelar)
        self.layout.addLayout(btn_layout)

    def obtener_datos(self):
        item = self.item_input.text().strip()
        descripcion = self.descripcion_input.text().strip()
        cantidad = self.cantidad_input.text().strip()

        if not item or not descripcion or not cantidad:
            raise ValueError("Todos los campos son obligatorios.")

        return {
            "item": item,
            "descripcion": descripcion,
            "cantidad": cantidad
        }