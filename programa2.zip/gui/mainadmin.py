from PyQt6 import QtWidgets, uic
from PyQt6.QtWidgets import QMessageBox, QTableWidgetItem
from data.nota_pedido import NotaPedidoData
from data.usuario import UsuarioData
from model.user import Usuario


class MainWindowAdmin:
    def __init__(self, usuario=None):
        self.usuario_logueado = usuario  # Guardar el usuario
        self.main = uic.loadUi("gui/admin.ui")
        self.usuario_data = UsuarioData()
        self.notapedido = NotaPedidoData()
        self.initGUI()
        self.conectar_botones()
        self.main.showMaximized()

    def initGUI(self):
        self.cargar_notas_pedido()

    def conectar_botones(self):
        self.main.btnCrearNP_Admin.clicked.connect(self.crear_nota_pedido)
        self.main.btnEditarTablaNPactiva.clicked.connect(self.editar_nota_pedido)
        self.main.btnEditarTablaOCactiva.clicked.connect(self.editar_orden_compra)
        self.main.actionCerrar_Sesion_Admin.triggered.connect(self.cerrar_sesion)

    def cargar_usuarios(self):
        usuarios = self.usuario_data.obtener_todos_los_usuarios()
        if usuarios:
            self.main.tablaNPactivasAdmin.setRowCount(len(usuarios))
            for row, usuario in enumerate(usuarios):
                self.main.tablaNPactivasAdmin.setItem(row, 0, QTableWidgetItem(str(usuario.id)))
                self.main.tablaNPactivasAdmin.setItem(row, 1, QTableWidgetItem(usuario.nom_usuario))
                self.main.tablaNPactivasAdmin.setItem(row, 2, QTableWidgetItem(usuario.apellido_usuario))
                self.main.tablaNPactivasAdmin.setItem(row, 3, QTableWidgetItem(usuario.usuario))
                # Añade más columnas según corresponda
        else:
            QMessageBox.information(self.main, "Sin Datos", "No hay usuarios registrados.")

    def crear_nota_pedido(self):
        from gui.nota_pedido_form import NotaPedidoForm
        self.form_nota_pedido = NotaPedidoForm()
        self.form_nota_pedido.show()

    def editar_nota_pedido(self):
        selected_row = self.main.tablaNPactivasAdmin.currentRow()
        if selected_row >= 0:
            id_nota_pedido = self.main.tablaNPactivasAdmin.item(selected_row, 0).text()
            nota_pedido = self.notapedido.obtener_nota_pedido_por_id(id_nota_pedido)  # Debes implementarlo
            if nota_pedido:
                from gui.nota_pedido_form import NotaPedidoForm
                self.form_nota_pedido = NotaPedidoForm(usuario=self.usuario, nota_pedido=nota_pedido)
                self.form_nota_pedido.show()
            else:
                QMessageBox.warning(self.main, "Error", "Nota de pedido no encontrada.")
        else:
            QMessageBox.warning(self.main, "Seleccionar", "Por favor, seleccione una fila.")

    def editar_orden_compra(self):
        selected_row = self.main.tablaOCactivasAdmin.currentRow()
        if selected_row >= 0:
            nro_oc = self.main.tablaOCactivasAdmin.item(selected_row, 0).text()
            QMessageBox.information(self.main, "Editar OC", f"Editando Orden de Compra Nro: {nro_oc}")
        else:
            QMessageBox.warning(self.main, "Seleccionar", "Por favor, seleccione una orden de compra.")

    def cargar_notas_pedido(self):
        try:
            # Obtener todas las notas de pedido desde la BD
            notas_pedido = self.notapedido.obtener_todas_las_notas_pedido()
            
            if notas_pedido:
                self.main.tablaNPactivasAdmin.setRowCount(len(notas_pedido))
                
                for row, nota in enumerate(notas_pedido):
                    self.main.tablaNPactivasAdmin.setItem(row, 0, QTableWidgetItem(str(nota.numero)))
                    self.main.tablaNPactivasAdmin.setItem(row, 1, QTableWidgetItem(nota.descripcion or ""))
                    self.main.tablaNPactivasAdmin.setItem(row, 2, QTableWidgetItem(str(nota.sector_id)))
                    self.main.tablaNPactivasAdmin.setItem(row, 3, QTableWidgetItem(nota.fecha_creacion or ""))
                    self.main.tablaNPactivasAdmin.setItem(row, 4, QTableWidgetItem(nota.fecha_entrega or ""))
                    self.main.tablaNPactivasAdmin.setItem(row, 5, QTableWidgetItem(nota.prioridad or ""))
                    self.main.tablaNPactivasAdmin.setItem(row, 6, QTableWidgetItem(nota.estado or ""))
            else:
                QMessageBox.information(self.main, "Sin Datos", "No hay notas de pedido registradas.")
        except Exception as e:
            QMessageBox.critical(self.main, "Error", f"No se pudieron cargar las notas de pedido: {e}")

    def cerrar_sesion(self):
        from gui.login import LoginWindow
        self.main.close()
        self.login_window = LoginWindow()
        self.login_window.show()