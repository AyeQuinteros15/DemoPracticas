from PyQt6.QtWidgets import QMainWindow
from PyQt6 import uic
from PyQt6.QtCore import QDate

class NotaPedidoForm(QMainWindow):
    def __init__(self, usuario=None):
        super().__init__()
        self.usuario = usuario
        self.setWindowTitle("Crear/Editar Nota de Pedido")
        uic.loadUi("gui/crear_np.ui", self)
        self.initGUI()
    
    def initGUI(self):
        self.fechaCrearNP.setDate(QDate.currentDate())
        self.fechaEntregaCrearNP.setDate(QDate.currentDate())