from PyQt6 import QtWidgets, uic
from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QMessageBox
from data.usuario import UsuarioData
from data.nota_pedido import NotaPedidoData
from model.nota_pedido import NotaPedido


class CrearNotaPedidoWindow:
    def __init__(self, usuario=None):
        self.ventana = uic.loadUi("gui/crear_np.ui")
        self.usuario = usuario  # El usuario logueado
        self.usuario_data = UsuarioData()
        self.nota_pedido_data = NotaPedidoData()
        self.initGUI()
        self.cargar_datos_iniciales()
        self.conectar_eventos()
        self.ventana.show()

    def initGUI(self):
        self.ventana.fechaCrearNP.setDate(QDate.currentDate())
        self.ventana.fechaEntregaCrearNP.setDate(QDate.currentDate())

        if self.usuario:
            nombre_completo = f"{self.usuario.nom_usuario} {self.usuario.apellido_usuario}"
            self.ventana.txtGerenteSolicitante.setText(nombre_completo)
            self.ventana.txtGerenteSolicitante.setReadOnly(True)  # Opcional: evitar edición

    def conectar_eventos(self):
        self.ventana.btnAgregarItem.clicked.connect(self.agregar_item)
        self.ventana.actionGenerar_NP.triggered.connect(self.guardar_nota_pedido)
        self.ventana.actionCancelar_NP.triggered.connect(self.cancelar)

    def cargar_datos_iniciales(self):
        # Cargar sectores
        sectores = self.usuario_data.obtener_sectores()  # Debes tener este método
        for sector in sectores:
            self.ventana.boxSectorNP.addItem(sector.nombre, sector.id)

        # Cargar sucursales
        sucursales = self.usuario_data.obtener_sucursales()  # También debe existir
        for sucursal in sucursales:
            self.ventana.boxSucursalNP.addItem(sucursal.nom_suc, sucursal.id)

        # Si hay usuario logueado, mostrar sus datos
        if self.usuario:
            pass  # Aquí puedes rellenar datos si es necesario

    def validar_formulario(self):
        if not self.ventana.txtNumNP.text().strip():
            QMessageBox.warning(self.ventana, "Campo requerido", "El número de NP es obligatorio.")
            return False
        if not self.ventana.txtGerenteSolicitante.text().strip():
            QMessageBox.warning(self.ventana, "Campo requerido", "El gerente solicitante es obligatorio.")
            return False
        return True

    def obtener_datos_formulario(self):
        sector_index = self.ventana.boxSectorNP.currentIndex()
        sector_id = self.ventana.boxSectorNP.itemData(sector_index)

        return NotaPedido(
            numero=self.ventana.txtNumNP.text(),
            usuario_id=self.usuario.id if self.usuario else 1,  # Ajusta según sesión
            descripcion="",  # Lo puedes agregar si usas un campo oculto
            prioridad=0,     # Puedes vincularlo a un QCheckBox o QSpinBox
            fecha_entrega=self.ventana.fechaEntregaCrearNP.date().toString("yyyy-MM-dd"),
            gerente_solicitante=self.ventana.txtGerenteSolicitante.text(),
            observaciones=self.ventana.txtObservacionesCrearNP.toPlainText(),
            archivo_adjunto=self.ventana.txtAdjArchivo.text(),
            sector_id=sector_id
        )

    def guardar_nota_pedido(self):
        from data.item_np import ItemNPData
        if not self.validar_formulario():
            return

        nota_pedido = self.obtener_datos_formulario()

        if self.nota_pedido_data.guardar(nota_pedido):
            # Generar número automático basado en el id asignado
            numero_automatico = f"NP-{nota_pedido.id:04d}"  # Formato: NP-0001

            # Actualizar el campo txtNumNP
            self.ventana.txtNumNP.setText(numero_automatico)

            # Actualizar el objeto nota_pedido con el nuevo número
            nota_pedido.numero = numero_automatico
            self.nota_pedido_data.guardar(nota_pedido)  # Guardar de nuevo con el número actualizado

            QMessageBox.information(self.ventana, "Éxito", "Nota de Pedido guardada correctamente.")

            # Guardar ítems si los hay
            items = []
            for row in range(self.ventana.tablaItemCrearNP.rowCount()):
                item = self.ventana.tablaItemCrearNP.item(row, 0).text()
                descripcion = self.ventana.tablaItemCrearNP.item(row, 1).text()
                cantidad = int(self.ventana.tablaItemCrearNP.item(row, 2).text())
                items.append({
                    "descripcion": descripcion,
                    "cantidad": cantidad
                })

            item_np_data = ItemNPData()
            item_np_data.guardar_items_de_nota(items, nota_pedido.id)

            self.ventana.close()
        else:
            QMessageBox.critical(self.ventana, "Error", "No se pudo guardar la Nota de Pedido.")
    
    def cancelar(self):
            self.ventana.close()

    def agregar_item(self):
        from gui.agregar_item import AgregarItemDialog
        dialog = AgregarItemDialog(self.ventana)
        if dialog.exec() == QtWidgets.QDialog.DialogCode.Accepted:
            item = dialog.obtener_datos()
            row = self.ventana.tablaItemCrearNP.rowCount()
            self.ventana.tablaItemCrearNP.insertRow(row)
            self.ventana.tablaItemCrearNP.setItem(row, 0, QtWidgets.QTableWidgetItem(item["item"]))
            self.ventana.tablaItemCrearNP.setItem(row, 1, QtWidgets.QTableWidgetItem(item["descripcion"]))
            self.ventana.tablaItemCrearNP.setItem(row, 2, QtWidgets.QTableWidgetItem(str(item["cantidad"])))