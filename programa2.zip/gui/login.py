from PyQt6 import QtWidgets, uic
from PyQt6.QtWidgets import QMessageBox
from data.usuario import UsuarioData
from gui.mainadmin import MainWindowAdmin
from gui.notapedido import CrearNotaPedidoWindow
from model.user import Usuario_Sesion


class Login():
    def __init__(self):
        self.login=uic.loadUi("gui/login.ui")
        self.initGUI()
        self.login.lblMensaje.setText("")
        self.login.show()

    def ingresar(self):
        if len(self.login.txtUsuarioLogin.text())<2:
              self.login.lblMensaje.setText("Ingrese un usuario válido")
              self.login.txtUsuarioLogin.setFocus()
        elif len(self.login.txtClaveLogin.text())<2:
             self.login.lblMensaje.setText("Ingrese una contraseña válida")
             self.login.txtClaveLogin.setFocus()
        else:
            Usu = Usuario_Sesion(usuario=self.login.txtUsuarioLogin.text(), password=self.login.txtClaveLogin.text())
            UsuData = UsuarioData()
            res = UsuData.login(Usu)

            if res:
                self.login.hide()

                if res.perfil_id == 1:  # Administrador
                    self.main_admin = MainWindowAdmin(usuario=res)
                    self.main_admin.main.show()
                elif res.perfil_id == 2:  # Operador
                    self.main_operador = CrearNotaPedidoWindow(usuario=res)
                    self.main_operador.ventana.show()
                else:
                    QMessageBox.warning(self.login, "Acceso denegado", "Perfil no reconocido.")
                    self.login.show()
            else:
                self.login.lblMensaje.setText("DATOS INCORRECTOS")
               
    
    def initGUI(self):
        self.login.btnAccederLogin.clicked.connect(self.ingresar)